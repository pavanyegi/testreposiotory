package com.androiddownloaddemo;

/**
 * Created by SONU on 29/10/15.
 */
public class Utils {

    //String Values to be Used in App
    public static final String downloadDirectory = "Androhub Downloads";
    public static final String mainUrl = "http://androhub.com/demo/";
    public static final String downloadPdfUrl = "http://androhub.com/demo/demo.pdf";
    public static final String downloadDocUrl = "http://androhub.com/demo/demo.doc";
    public static final String downloadZipUrl = "http://androhub.com/demo/demo.zip";
    public static final String downloadVideoUrl = "http://androhub.com/demo/demo.mp4";
    public static final String downloadMp3Url = "http://androhub.com/demo/demo.mp3";
}
